import { app, PORT } from "./app.js";
import connectDB from "./db/index.js";

connectDB()
  .then(() => {
    app.listen(PORT, () => {
      console.warn(`Server listening on  Port : ${PORT}`);
    });
  })
  .catch((error) => {
    console.log(`MongoDB connection error: ${error}`);
  });
