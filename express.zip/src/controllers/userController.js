import { asyneHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import User from "../models/user.models.js";
import { uploadCloudinary, deleteFormCloudinary } from "../utils/cloudinary.js";
import { ApiResponse } from "../utils/ApiResponse.js";

const generateAccessAndRefreshToken = async (userId) => {
  try {
    const user = await User.findById(userId);
    if (!user) {
      throw new ApiError("User not found");
    }
    const userAccessToken = user.generateAccessToken();
    const userRefreshToken = user.generateRefreshToken();
    user.refreshToken = userRefreshToken;
    await user.save({ validateBeforeSave: false });
    return { userAccessToken, userRefreshToken };
  } catch (error) {
    throw new ApiError(
      500,
      "Something went wrong generating access token and refresh token"
    );
  }
};

const registerUser = asyneHandler(async (req, res) => {
  const { fullName, userName, email, password } = req.body;

  // Validate

  if (
    [fullName, userName, email, password].some((field) => field?.trim() === "")
  ) {
    throw new ApiError(400, "All fields must be required");
  }

  const existedUser = await User.findOne({
    $or: [{ fullName }, { email }],
  });

  if (existedUser) {
    throw new ApiError(409, "User already exists, please create a new one ...");
  }

  console.warn(req.files);

  const avatarLocalPath = req.files?.avatar?.[0]?.path;
  const coverLocalPath = req.files?.coverImage?.[0]?.path;

  // if (avatarLocalPath) {
  //   throw new ApiError(400, "Avatar File is missing");
  // } else if (coverLocalPath) {
  //   throw new ApiError(400, "CoverImage File is missing");
  // }

  // const avatar = await uploadCloudinary(avatarLocalPath);
  // let coverImage = "";
  // if (coverImage) {
  //   coverImage = await uploadCloudinary(coverLocalPath);
  // }

  let avatar;
  try {
    avatar = await uploadCloudinary(avatarLocalPath);
    console.log("Uploading avatar", avatar);
  } catch (error) {
    console.log("Error Uploading Avatar", error);
    throw new ApiError(500, "Failed to upload Avatar");
  }
  let coverImage;
  try {
    coverImage = await uploadCloudinary(coverLocalPath);
    console.log("Uploading coverImage", coverImage);
  } catch (error) {
    console.log("Error Uploading coverImage", error);
    throw new ApiError(500, "Failed to upload coverImage");
  }

  try {
    const user = await User.create({
      fullName,
      avatar: avatar.url,
      coverImage: coverImage?.url || "",
      email,
      password,
      userName: userName.toLowerCase(),
    });

    const createdUser = await User.findById(user._id).select(
      "-password -refreshToken "
    );

    if (!createdUser) {
      throw new ApiError(500, "Something went wrong when creating user");
    }

    return res
      .status(201)
      .json(new ApiResponse(201, createdUser, "User created successfully"));
  } catch (error) {
    console.log("User creation Failed", error);
    if (avatar) {
      await deleteFormCloudinary(avatar.public_id);
    }
    if (coverImage) {
      await deleteFormCloudinary(coverImage.public_id);
    }
    throw new ApiError(
      500,
      "Something went wrong when creating user and Images were Deleted"
    );
  }
});

const loginUser = asyneHandler(async (req, res) => {
  const { userName, email } = req.body;
  if (!userName || !email) {
    throw new ApiError(400, "Both userName and email must be provided");
  }
  const user = await User.find({
    $or: [{ userName }, { email }],
  });

  if (!user) {
    throw new ApiError(404, "User not found");
  }

  // Validate Password

  const isPasswordValid = await user.isPasswordCorrect(password);
  if (!isPasswordValid) {
    throw new ApiError(404, "Invalid password");
  }

  const { userAccessToken, userRefreshToken } =
    await generateAccessAndRefreshToken(user._id);

  const loggedInUser = await User.findById(user._id).select(
    "-password -refreshToken"
  );

  if (!loggedInUser) {
    throw new ApiError(404, " User already logged in ...");
  }

  const options = {
    httpOnly: true,
    secure: false,
  };

  return res
    .status(200)
    .cookie("userAccessToken", userAccessToken, options)
    .cookie("userRefreshToken", userRefreshToken, options)
    .json(
      new ApiResponse(
        200,
        { user: loggedInUser, userRefreshToken, userAccessToken },
        " User Logged In Successfully"
      )
    );
});


export { registerUser ,loginUser };
